package com.MyRestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
