package com.MyRestapi.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.MyRestapi.Model.Student;
import com.MyRestapi.Service.MyRestApiService;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@RequestMapping("MyRestApi")
public class MyRestApiController {
	
	@Autowired
	
	MyRestApiService apiService;
	
	@PostMapping("add")
	public ResponseEntity <String>addStudent(@RequestBody Student stud){
		return apiService.addStudent(stud);
	}
	
	@GetMapping("get")
	public ResponseEntity <List<Student>>getStudent(){
		return apiService.getStudent();
		
	}
	@PutMapping("Update")
	public  ResponseEntity <String>updateStudent(@RequestBody Student stud){
		return apiService.updateStudent(stud);
	}
	@DeleteMapping("delete")
	public  ResponseEntity <String>deleteStudent(@PathVariable int rollno){
return apiService.deleteStudent(rollno);
}
}
